# Lie count film, draft for the Sol check

Film clock in seconds. Each segment is one place; sheets are 2 frames/s, strips 12 frames/s.

## lc10-01-terrace (film 0.00-25.60 s): sheet lc10-01-terrace-sheet.jpg

- 0.00 shot "01 delicious close"
  - 0.10 NARRATOR: What if you could see how many times everyone has lied to you?
- 2.50 shot "01 delicious two +"
  - 3.99 MASH: delicious!
- 4.99 shot "01 delicious close"
  - 4.99 NARRATOR: Your best friend just hit two hundred and twelve.
- 7.67 shot "01 delicious close +"
  - 8.31 NARRATOR: Remember that number.
- 10.34 shot "01 delicious two"
  - 10.34 NARRATOR: All about your cinnamon buns.
- 12.95 shot "02 the morning wide"
  - 13.05 NARRATOR: It started this morning. Everyone had a number over their head.
- 16.15 shot "02 the morning close +"
  - 18.46 NARRATOR: And only you could see them.
- 19.89 shot "02 the morning close"
  - 19.89 BAKER: fresh today!
  - 21.28 NARRATOR: The baker. Four. All of them about bread.
- 22.75 shot "02 the morning close +"

## lc10-02-street (film 25.60-56.41 s): sheet lc10-02-street-sheet.jpg

- 25.60 shot "03 strangers wide"
  - 25.70 MOVER: not heavy at all!
  - 25.80 mover walks 4.0 s: strip lc10-02-street-walk-mover-0.2.jpg
  - 27.02 NARRATOR: Strangers had small numbers. They hadn't had the time.
- 28.48 shot "03 strangers close +"
- 31.37 shot "04 the loud one wide"
  - 31.57 chip walks 1.0 s: strip lc10-02-street-walk-chip-6.0.jpg
- 31.77 shot "04 the loud one two"
  - 31.77 CHIP: sorry! the bus was late!
  - 33.31 NARRATOR: Your loudest friend. Thirty-eight.
- 34.02 shot "04 the loud one close +"
- 36.27 shot "04 the loud one wide"
  - 36.39 NARRATOR: There is no bus.
- 38.34 shot "05 trust me two"
  - 38.44 WEDGE: trust me. it's going to rain on friday.
  - 41.33 NARRATOR: And the friend who says 'trust me' twenty times a day...
- 41.54 shot "05 trust me close +"
- 43.47 shot "05 trust me close +"
- 45.40 shot "05 trust me close"
  - 45.40 NARRATOR: Zero. Not once. Not ever.
- 47.66 shot "05 trust me two +"
- 49.92 shot "05 trust me close"
- 50.20 shot "05b your own head close"
  - 50.30 NARRATOR: And over your own head?
  - 52.07 NARRATOR: Nothing. Apparently, you were the only honest one in town.
- 53.30 shot "05b your own head two +"

## lc10-03-terrace (film 56.41-68.06 s): sheet lc10-03-terrace-sheet.jpg

- 56.41 shot "06 why 212 ots"
  - 56.51 NARRATOR: Strangers, single digits. The baker, four. The loud one, thirty-eight.
- 59.61 shot "06 why 212 close +"
- 61.92 shot "06 why 212 close +"
- 64.23 shot "06 why 212 close"
  - 64.23 NARRATOR: So why was your best friend at two hundred and twelve?
- 66.14 shot "06 why 212 two +"

## lc10-04-counter (film 68.06-76.88 s): sheet lc10-04-counter-sheet.jpg

- 68.06 shot "07 fresh today close"
  - 68.16 NARRATOR: At first, it was the best power in the world.
- 70.71 shot "07 fresh today close +"
  - 71.92 BAKER: all baked this morning!
- 73.36 shot "07 fresh today close"
  - 73.36 BAKER: ...half price.
  - 74.81 NARRATOR: Nobody could fool you.

## lc10-05-street (film 76.88-86.27 s): sheet lc10-05-street-sheet.jpg

- 76.88 shot "08 the fries two"
  - 76.98 SPUD: who ate my fries?
- 78.44 shot "08 the fries close +"
  - 78.44 CHIP: not me!
- 79.50 shot "08 the fries close"
- 79.86 shot "08 the fries two"
  - 79.86 CHIP: ...it was me.
  - 80.92 NARRATOR: Not about bread. Not about fries. Not about anything.
- 83.06 shot "08 the fries close +"

## lc10-06-room (film 86.27-99.00 s): sheet lc10-06-room-sheet.jpg

- 86.27 shot "09 game night group"
  - 86.37 NARRATOR: Game night. Your friends bluffed.
- 89.39 shot "09 game night close +"
  - 89.39 CHIP: i've got nothing good. promise.
- 91.55 shot "09 game night close"
  - 91.55 SPUD: you've got four aces.
- 93.10 shot "09 game night group"
  - 93.10 NARRATOR: You won every game that night.
  - 95.37 NARRATOR: It was the last game night they invited you to.
- 96.05 shot "09 game night close +"

## lc10-07-river (film 99.00-113.78 s): sheet lc10-07-river-sheet.jpg

- 99.00 shot "10 busy friday two"
  - 99.10 SPUD: movie on friday?
- 100.44 shot "10 busy friday close +"
  - 100.44 MASH: can't. i'm busy.
- 102.06 shot "10 busy friday close"
  - 102.06 NARRATOR: Two hundred and thirteen.
  - 104.29 NARRATOR: Busy. Every Friday. For a whole year.
- 105.23 shot "10 busy friday two +"
- 108.41 shot "10 busy friday two"
  - 108.41 NARRATOR: You had never asked what he did on Fridays.
- 111.09 shot "10 busy friday two +"
  - 111.62 NARRATOR: Now you had a number.

## lc10-08-bridge (film 113.78-118.92 s): sheet lc10-08-bridge-sheet.jpg

- 113.78 shot "11 the catch alone"
  - 113.88 NARRATOR: But there's a catch.
- 115.78 shot "11 the catch close"
  - 115.78 NARRATOR: It tells you how many.
  - 117.47 NARRATOR: Never why.

## lc10-09-street (film 118.92-123.83 s): sheet lc10-09-street-sheet.jpg

- 118.92 shot "12 nice sweater two"
  - 119.02 CHIP: nice sweater!
- 120.02 shot "12 nice sweater close"
  - 120.20 NARRATOR: Every compliment came with a number.
- 121.92 shot "12 nice sweater two +"

## lc10-10-counter (film 123.83-127.22 s): sheet lc10-10-counter-sheet.jpg

- 123.83 shot "13 nice day ots"
  - 123.93 BAKER: have a lovely day!
  - 125.40 NARRATOR: Every smile.

## lc10-11-river (film 127.22-148.94 s): sheet lc10-11-river-sheet.jpg

- 127.22 shot "14 do you like them two"
  - 127.32 NARRATOR: So you tested your best friend.
- 129.53 shot "14 do you like them close +"
  - 129.53 SPUD: do you actually like my buns?
  - 131.31 MASH: love them.
- 132.36 shot "14 do you like them close"
  - 132.36 NARRATOR: Two hundred and fourteen.
- 134.78 shot "14b asked around two"
  - 134.88 NARRATOR: So you asked around.
- 136.43 shot "14b asked around close +"
  - 136.43 SPUD: why does he lie to me so much?
  - 138.22 CHIP: him? he never lies!
- 139.71 shot "14b asked around close"
  - 139.71 NARRATOR: Even your friends were lying about him.
- 142.56 shot "14b asked around two"
  - 142.56 SPUD: does he lie to me?
  - 143.73 WEDGE: trust me. ask him yourself.
- 145.75 shot "14b asked around close +"
  - 146.28 NARRATOR: The only straight answer in town.

## lc10-12-street (film 148.94-161.25 s): sheet lc10-12-street-sheet.jpg

- 148.94 shot "15 are you lying group"
  - 149.04 NARRATOR: And you couldn't stop asking.
- 150.86 shot "15 are you lying close +"
  - 150.86 SPUD: are you lying right now?
  - 152.17 CHIP: no!
- 152.27 shot "15 are you lying group +"
  - 152.88 SPUD: and now?
- 153.59 shot "15 are you lying close +"
  - 153.59 CHIP: ...no!
  - 154.53 chip walks 2.2 s: strip lc10-12-street-walk-chip-5.6.jpg
- 155.03 shot "15 are you lying two"
  - 155.03 WEDGE: trust me. that was weird.
  - 157.40 NARRATOR: Even he agreed. And he doesn't lie.
- 158.14 shot "15 are you lying close +"

## lc10-13-bridge (film 161.25-168.75 s): sheet lc10-13-bridge-sheet.jpg

- 161.25 shot "16 fewer lies alone"
  - 161.35 NARRATOR: One by one, people stopped talking to you.
- 164.45 shot "16 fewer lies close +"
  - 165.14 NARRATOR: Which, technically, meant fewer lies.
- 166.60 shot "16 fewer lies close +"

## lc10-14-rain (film 168.75-194.36 s): sheet lc10-14-rain-sheet.jpg

- 168.75 shot "17 you followed him wide"
  - 168.85 NARRATOR: So on Friday, you followed him.
  - 171.65 mash walks 4.0 s: strip lc10-14-rain-walk-mash-2.9.jpg
- 171.95 shot "17 you followed him close +"
  - 172.03 NARRATOR: The bakery. After closing time.
- 175.62 shot "18 told you two"
  - 175.72 WEDGE: told you. rain.
  - 177.45 NARRATOR: He was right about the rain. He's always right.
- 178.53 shot "18 told you close +"
- 181.43 shot "19 fogged windows close"
  - 181.53 NARRATOR: You waited an hour in the rain.
  - 184.02 NARRATOR: The windows were fogged. Just shadows... and somebody laughing.
- 184.63 shot "19 fogged windows close +"
- 187.83 shot "19 fogged windows close +"
  - 188.98 NARRATOR: Laughing. While you stood in the rain.
- 191.03 shot "19 fogged windows close +"
  - 192.77 NARRATOR: That was enough.

## lc10-15-bridge (film 194.36-212.42 s): sheet lc10-15-bridge-sheet.jpg

- 194.36 shot "20 where were you two"
  - 194.46 NARRATOR: Saturday.
- 197.92 shot "20 where were you close +"
  - 197.92 SPUD: where were you last night?
  - 199.37 MASH: home. sleeping.
- 199.47 shot "20 where were you two +"
- 201.38 shot "20 where were you ots"
  - 201.38 SPUD: two hundred and fifteen!
- 202.77 shot "20 where were you ots"
  - 202.77 MASH: what?
- 203.61 shot "20 where were you ots"
  - 203.61 SPUD: i can see it! every single lie!
- 205.75 shot "20 where were you close"
  - 206.23 MASH: ...okay.
- 207.28 shot "20 where were you two"
  - 207.38 mash walks 4.5 s: strip lc10-15-bridge-walk-mash-13.0.jpg
  - 207.64 NARRATOR: He didn't even try to explain.
- 209.85 shot "20 where were you close +"
  - 210.01 NARRATOR: You were right about the number.

## lc10-16-balcony (film 212.42-234.40 s): sheet lc10-16-balcony-sheet.jpg

- 212.42 shot "22 nobody called alone"
  - 212.52 NARRATOR: That night, nobody called.
  - 215.35 NARRATOR: So you ate your cinnamon buns. Alone.
- 215.62 shot "22 nobody called close +"
- 219.16 shot "22 nobody called close"
  - 219.64 NARRATOR: They were... terrible.
- 222.09 shot "22 nobody called close +"
  - 222.69 NARRATOR: They had always been terrible.
- 225.03 shot "23 every week close"
  - 225.13 NARRATOR: Every week, he said they were delicious.
- 228.17 shot "23 every week close +"
  - 228.58 NARRATOR: And every week, you baked them again.
- 231.32 shot "23 every week alone"
  - 231.32 NARRATOR: Maybe some lies weren't against you.

## lc10-17-street (film 234.40-257.60 s): sheet lc10-17-street-sheet.jpg

- 234.40 shot "24 your birthday wide"
  - 234.50 NARRATOR: Sunday. Your birthday.
  - 236.76 baker walks 2.6 s: strip lc10-17-street-walk-baker-2.4.jpg
- 237.32 shot "24 your birthday close +"
  - 237.32 BAKER: morning!
  - 238.50 NARRATOR: Nobody said a word about it.
- 238.60 shot "24 your birthday wide +"
  - 238.60 baker walks 4.0 s: strip lc10-17-street-walk-baker-4.2.jpg
- 241.31 shot "25 just sunday two"
  - 241.41 SPUD: guess what day it is!
- 242.69 shot "25 just sunday close +"
  - 242.69 CHIP: uh... sunday?
  - 244.07 SPUD: and?
- 244.17 shot "25 just sunday two +"
  - 244.86 CHIP: just sunday!
- 245.83 shot "25 just sunday close"
  - 245.83 NARRATOR: And then, the whole town started lying.
- 248.73 shot "26 no idea two"
  - 248.83 MOVER: no idea what day it is, mate.
  - 250.61 NARRATOR: About the same thing.
- 251.92 shot "26 no idea close"
  - 251.92 NARRATOR: Either the whole town forgot your birthday...
- 254.76 shot "26 no idea two +"
  - 254.87 NARRATOR: ...or the whole town was lying about it.

## lc10-18-bridge (film 257.60-265.45 s): sheet lc10-18-bridge-sheet.jpg

- 257.60 shot "26b stop counting close"
  - 257.70 NARRATOR: Two hundred and fifteen. You had counted every one.
- 260.80 shot "26b stop counting close +"
  - 261.84 NARRATOR: And you still didn't know a single why.
- 263.12 shot "26b stop counting close +"

## lc10-19-street (film 265.45-274.24 s): sheet lc10-19-street-sheet.jpg

- 265.45 shot "27 come with me two"
  - 265.55 WEDGE: trust me. come with me.
  - 267.62 NARRATOR: Only one friend still had a zero.
- 268.01 shot "27 come with me close +"
- 270.57 shot "27 come with me close"
  - 270.57 NARRATOR: So, for the first time, you trusted him.
- 273.36 shot "27 come with me wide"
  - 273.46 wedge walks 3.2 s: strip lc10-19-street-walk-wedge-8.0.jpg
  - 273.46 spud walks 3.4 s: strip lc10-19-street-walk-spud-8.0.jpg

## lc10-20-room (film 274.24-329.55 s): sheet lc10-20-room-sheet.jpg

- 274.24 shot "28 surprise wide"
  - 274.34 CHIP: surprise!
- 276.08 shot "28 surprise ots"
  - 276.50 NARRATOR: Your best friend. The baker. The loud one. Everyone.
- 279.11 shot "28 surprise close +"
- 282.13 shot "29 fridays two"
  - 282.23 MASH: every friday. here. learning to bake.
- 285.25 shot "29 fridays close +"
  - 285.25 MASH: your buns. but... a cake.
- 288.91 shot "29 fridays close"
  - 288.91 NARRATOR: Remember two hundred and twelve?
  - 291.80 NARRATOR: Every 'delicious'. Every 'I'm busy'. Every 'I'm sleeping'.
- 292.11 shot "29 fridays two +"
- 295.18 shot "29 fridays two +"
- 298.25 shot "29 fridays close"
  - 298.25 NARRATOR: And every single one of them... was for you.
- 301.82 shot "29b confessions close"
  - 301.92 CHIP: the bus! i was buying your present!
- 304.00 shot "29b confessions close"
  - 304.00 BAKER: the buns weren't fresh. i kept the fresh ones for your cake.
- 306.24 shot "29b confessions two +"
- 308.47 shot "29b confessions close"
  - 308.47 MOVER: the box was heavy. it was your present.
- 310.57 shot "29b confessions group"
  - 310.57 NARRATOR: Every number in town had a reason.
- 313.13 shot "29b confessions group +"
  - 313.60 NARRATOR: You'd just never asked.
- 315.69 shot "30 the cake close"
  - 315.79 NARRATOR: Then you tasted his cake.
  - 318.19 NARRATOR: It was terrible.
- 319.47 shot "30 the cake close"
- 319.89 shot "30 the cake close"
  - 319.89 MASH: well?
- 320.73 shot "30 the cake close"
  - 321.09 SPUD: it's delicious.
  - 322.59 NARRATOR: And for the first time... you lied too.
- 323.56 shot "30 the cake two +"
- 326.39 shot "30 the cake two"
  - 326.39 MASH: really?
- 327.21 shot "30 the cake close"
  - 327.21 SPUD: really.
  - 328.15 NARRATOR: Twice.

## lc10-21-hill (film 329.55-343.37 s): sheet lc10-21-hill-sheet.jpg

- 329.55 shot "31 the sunset wide"
  - 330.25 NARRATOR: Two hundred and fifteen to two.
- 333.53 shot "31 the sunset close"
  - 333.53 WEDGE: trust me. the cake is terrible.
- 335.88 shot "31 the sunset close"
- 336.30 shot "31 the sunset close"
  - 336.30 CHIP: next year, i bake!
- 337.82 shot "31 the sunset close"
  - 337.82 WEDGE: trust me. please don't.
- 339.89 shot "31 the sunset wide"
  - 339.89 NARRATOR: You've got some catching up to do.

